
  <section class="body">


    <div class="contenedor2">
      <div class="slide active">
        <img src="./public/images/tendencia/boca_lengua.png" alt="">
        <div class="info">
        <h2>¿Aún no tienes el tuyo?</h2>
          <p>¡Ponte en contacto con nosotros!</p>
        </div>
      </div>

     <div class="slide">
        <img src="./public/images/fondos/fondo_s.jpg" alt="">
        <div class="info">
        <h2>¿Aún no tienes el tuyo?</h2>
          <p>¡Ponte en contacto con nosotros!</p>
        </div>
      </div>
      <div class="slide">
        <img src="./public/images/fondos/fondo_s.jpg" alt="">
        <div class="info">
        <h2>¿Aún no tienes el tuyo?</h2>
          <p>¡Ponte en contacto con nosotros!</p>

        </div>
      </div>
      <div class="slide">
        <img src="./public/images/fondos/fondo_s.jpg" alt="">
        <div class="info">
        <h2>¿Aún no tienes el tuyo?</h2>
          <p>¡Ponte en contacto con nosotros!</p>
      </div>
      </div>
      <div class="slide">
        <img src="./public/images/fondos/fondo_s.jpg" alt="">
        <div class="info">
        <h2>¿Aún no tienes el tuyo?</h2>
          <p>¡Ponte en contacto con nosotros!</p>
        </div>
      </div>
      <div class="navigation">
        <i class="fas fa-chevron-left prev-btn"></i>
        <i class="fas fa-chevron-right next-btn"></i>
      </div>
      <!--<div class="navigation-visibility">
        <div class="slide-icon active"></div>
        <div class="slide-icon"></div>
        <div class="slide-icon"></div>
        <div class="slide-icon"></div>
        <div class="slide-icon"></div>
      </div>-->
      </div>
  </section>

      

