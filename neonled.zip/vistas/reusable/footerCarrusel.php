<script type="text/javascript" src="../public/js/slider.js" defer></script>
<script type="text/javascript" src="../public/js/tienda/ControladorCategorias.js" ></script>