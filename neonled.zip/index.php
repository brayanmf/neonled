<?php 
header('location:inicio.php');

echo "hola3";



echo "prueba de rama";

 ?>